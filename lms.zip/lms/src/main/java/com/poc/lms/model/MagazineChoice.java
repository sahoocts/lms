package com.poc.lms.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;

public class MagazineChoice {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long magazinechoiceId;
	@NotBlank
	@Column(name= "magazine_name")
	private String magazinename;
	
	@ManyToMany
	private Member members;
	public long getMagazinechoiceId() {
		return magazinechoiceId;
	}

	public void setMagazinechoiceId(long magazinechoiceId) {
		this.magazinechoiceId = magazinechoiceId;
	}

	public String getMagazinename() {
		return magazinename;
	}

	public void setMagazinename(String magazinename) {
		this.magazinename = magazinename;
	}

	public Member getMembers() {
		return members;
	}

	public void setMembers(Member members) {
		this.members = members;
	}

}
