package com.poc.lms.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.poc.lms.model.Member;
import com.poc.lms.repository.MemberRepository;

@Repository("MemberDAO")
public class MemberDaoImpl implements MemberDAO {

	@Autowired
	MemberRepository memberRepository;

	@Override
	public Member save(Member member) {

		return memberRepository.save(member);

	}

}
