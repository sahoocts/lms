package com.poc.lms.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;

public class BookChoice {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long bookChoiceId;
	
	public long getBookChoiceId() {
		return bookChoiceId;
	}

	public void setBookChoiceId(long bookChoiceId) {
		this.bookChoiceId = bookChoiceId;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public Member getMembers() {
		return members;
	}

	public void setMembers(Member members) {
		this.members = members;
	}

	@NotBlank
	@Column(name= "book_name")
	private String bookname;
	
	@ManyToMany
	private Member members;
}
