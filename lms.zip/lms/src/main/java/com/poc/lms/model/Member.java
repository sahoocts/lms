package com.poc.lms.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "member")
@EntityListeners(AuditingEntityListener.class)
public class Member {

	@Id
	@Column(name = "Member_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long Id;

	@NotBlank
	@Column(name = "first_name")
	private String firstname;

	@NotBlank
	@Column(name = "last_name")
	private String lastname;

	@NotBlank
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date date;

	@Temporal(TemporalType.TIMESTAMP)
	@NotBlank
	private Date dob;

	@OneToOne(mappedBy = "member")
	@JoinColumn(name = "Member_Id")
	private Address address;
	
	@NotBlank
	@Column(name = "member_Category")
	private MemberCategory memberCategory;
	
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "MEMBER_TABLE", joinColumns = {@JoinColumn(name = "Member_Id")},inverseJoinColumns = {@JoinColumn(name="Course_Id")})
	private Set<Course> courses;

	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "BOOKCHOICE_TABLE",joinColumns = {@JoinColumn(name="Member_Id")},inverseJoinColumns = {@JoinColumn(name="Bookchoice_Id")})
	private Set<BookChoice> BookChoices;

	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "MAGAZINECHOICE_TABLE",joinColumns = {@JoinColumn(name="Member_Id")},inverseJoinColumns = {@JoinColumn(name="Magazinechoice_Id")})
	private Set<MagazineChoice> MagazineChoices;
	
	
	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	public MemberCategory getMemberCategory() {
		return memberCategory;
	}

	public void setMemberCategory(MemberCategory memberCategory) {
		this.memberCategory = memberCategory;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

}
